package com.mkamuy.location;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.location.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;

public class TrafficMonitorActivity extends Activity {
    static final String PREF="mkamuy_traffic";
    private TextView status;
    private EditText api;
    private EditText homeAddress;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,14,24,12);
        root.setBackgroundColor(0xff101010);
        status = text("HOME TRAFFIC / S999", 19);
        root.addView(status);
        root.addView(text("Vehicle: sustained >40 km/h   |   Alert: +10 min   |   Check: 15 min",14));
        api = new EditText(this);
        api.setSingleLine(true);
        api.setTextColor(-1);
        api.setHintTextColor(0xffaaaaaa);
        api.setHint("Google Routes API key (stored on device)");
        api.setInputType(129); // password, don't display secrets on screen
        root.addView(api);
        Button save = button("SAVE API KEY");
        save.setOnClickListener(v -> {getSharedPreferences(PREF,0).edit().putString("api",api.getText().toString().trim()).apply(); api.setText(""); status.setText("API key saved locally");});
        root.addView(save);
        homeAddress = new EditText(this);
        homeAddress.setSingleLine(true);
        homeAddress.setTextColor(-1);
        homeAddress.setHintTextColor(0xffaaaaaa);
        homeAddress.setHint("Home street address (saved on S999 only)");
        homeAddress.setText(getSharedPreferences(PREF,0).getString("home_address",""));
        root.addView(homeAddress);
        Button saveAddress = button("SAVE HOME ADDRESS");
        saveAddress.setOnClickListener(v -> geocodeHomeAddress());
        root.addView(saveAddress);
        Button test = button("TEST NOTIFICATION");
        test.setOnClickListener(v -> testNotification());
        root.addView(test);
        Button home = button("SET CURRENT GPS POSITION AS HOME");
        home.setOnClickListener(v -> saveHome());
        root.addView(home);
        Button start = button("START TRAFFIC MONITOR");
        start.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},2);
            if (!hasLocation()) {requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},1);return;}
            if(!getSharedPreferences(PREF,0).contains("home_lat") || getSharedPreferences(PREF,0).getString("api","").isEmpty()){status.setText("Save HOME GPS and API key first");return;}
            Intent i=new Intent(this,TrafficMonitorService.class);
            if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
            status.setText("Monitoring active; persistent notification shown");
        });
        root.addView(start);
        Button stop=button("STOP TRAFFIC MONITOR");
        stop.setOnClickListener(v -> {stopService(new Intent(this,TrafficMonitorService.class)); status.setText("Monitoring stopped");});
        root.addView(stop);
        ScrollView scroller = new ScrollView(this); scroller.addView(root); setContentView(scroller);
    }
    private TextView text(String s,int size) {TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(-1);t.setPadding(0,6,0,6);return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);return b;}
    private boolean hasLocation(){return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED;}
    private void geocodeHomeAddress(){
        String address = homeAddress.getText().toString().trim();
        if(address.isEmpty()){status.setText("Enter your home address first");return;}
        status.setText("Looking up home address...");
        new Thread(() -> {
            try {
                Geocoder coder = new Geocoder(this,java.util.Locale.getDefault());
                java.util.List<Address> hits = coder.getFromLocationName(address,1);
                if(hits==null || hits.isEmpty()){runOnUiThread(()->status.setText("Address not found; try a fuller street address"));return;}
                Address point=hits.get(0);
                getSharedPreferences(PREF,0).edit().putString("home_lat",String.valueOf(point.getLatitude()))
                    .putString("home_lon",String.valueOf(point.getLongitude()))
                    .putString("home_address",address).apply();
                runOnUiThread(()->status.setText("HOME saved locally. Confirm the address is correct."));
            } catch(Exception e){runOnUiThread(()->status.setText("Address lookup unavailable. Use GPS-at-home option."));}
        }).start();
    }
    private void testNotification(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},2);
            status.setText("Allow notifications, then tap TEST again");return;
        }
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        String ch="mkamuy_test";
        if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(ch,"MKamuy test alerts",NotificationManager.IMPORTANCE_HIGH));
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,ch):new Notification.Builder(this);
        nm.notify(7830,b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("MKamuy test notification")
            .setContentText("Notifications are working on your S999").setAutoCancel(true)
            .setDefaults(Notification.DEFAULT_ALL).build());
        status.setText("Test notification sent");
    }
    private void saveHome(){
        if(!hasLocation()){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},1);return;}
        LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);
        Location best=null;
        for(String provider:lm.getProviders(true)) {try {Location loc=lm.getLastKnownLocation(provider);if(loc!=null && (best==null||loc.getTime()>best.getTime()))best=loc;}catch(SecurityException ignored){}}
        if(best==null || System.currentTimeMillis()-best.getTime()>120000){
            status.setText("Waiting for fresh GPS. Turn on Location and try again outdoors.");
            try {
                final LocationManager manager=lm;
                final LocationListener listener=new LocationListener(){@Override public void onLocationChanged(Location loc){saveCoordinates(loc);manager.removeUpdates(this);}};
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,0,0,listener,getMainLooper());
                new Handler(getMainLooper()).postDelayed(()->manager.removeUpdates(listener),30000);
            } catch(Exception e){status.setText("GPS unavailable: "+e.getMessage());}
        } else saveCoordinates(best);
    }
    private void saveCoordinates(Location loc){
        getSharedPreferences(PREF,0).edit().putString("home_lat",Double.toString(loc.getLatitude())).putString("home_lon",Double.toString(loc.getLongitude())).remove("home_address").apply();
        status.setText("HOME saved privately on this S999. No address uploaded to GitHub.");
    }
}

class TrafficMonitorService extends Service {
    static final String CHANNEL="mkamuy_traffic_monitor";
    private Handler handler;
    private boolean running;
    private long lastAlert=0;
    private long lastTrafficCheck=0;
    private int qualifyingFixes=0;
    private boolean vehicleDetected=false;
    private LocationListener movementListener;
    private LocationManager locationManager;
    private final Runnable task=new Runnable(){@Override public void run(){
        if(running){
            if(vehicleDetected && System.currentTimeMillis()-lastTrafficCheck>=15*60*1000L){
                lastTrafficCheck=System.currentTimeMillis(); checkTraffic();
            }
            handler.postDelayed(this,30*1000L);
        }
    }};
    @Override public void onCreate(){super.onCreate();handler=new Handler(getMainLooper()); NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Home traffic monitor",NotificationManager.IMPORTANCE_DEFAULT));}
    private Notification n(String title,String body){Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);return b.setSmallIcon(android.R.drawable.ic_dialog_map).setContentTitle(title).setContentText(body).setOngoing(true).build();}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        startForeground(7820,n("MKamuy traffic","Watching for vehicle travel >40 km/h"));
        if(!running){running=true;startMovementDetection();handler.post(task);}return START_NOT_STICKY;
    }
    private void startMovementDetection(){
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            postStatus("Precise GPS permission required for vehicle detection");return;
        }
        locationManager=(LocationManager)getSystemService(LOCATION_SERVICE);
        movementListener=new LocationListener(){
            @Override public void onLocationChanged(Location loc){
                if(!loc.hasSpeed() || (loc.hasSpeedAccuracy() && loc.getSpeedAccuracyMetersPerSecond()>5f))return;
                double kmh=loc.getSpeed()*3.6;
                if(kmh>40){qualifyingFixes++;}else{qualifyingFixes=0;vehicleDetected=false;}
                if(qualifyingFixes>=2 && !vehicleDetected){
                    vehicleDetected=true; lastTrafficCheck=0;
                    postStatus("Vehicle travel detected ("+(int)Math.round(kmh)+" km/h)");
                    handler.post(task);
                }
            }
        };
        try{
            if(locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,10000,0,movementListener,getMainLooper());
            else postStatus("Turn on GPS for vehicle recognition");
        }catch(SecurityException e){postStatus("GPS permission denied");}
    }
    @Override public void onDestroy(){
        running=false;handler.removeCallbacks(task);
        if(locationManager!=null && movementListener!=null)locationManager.removeUpdates(movementListener);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i){return null;}
    private void checkTraffic(){
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED)return;
        LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);
        Location latest=null;
        for(String p:lm.getProviders(true))try{Location l=lm.getLastKnownLocation(p);if(l!=null && (latest==null||l.getTime()>latest.getTime())) latest=l;}catch(Exception ignored){}
        if(latest==null || System.currentTimeMillis()-latest.getTime()>5*60*1000){
            try{
                LocationListener listener=new LocationListener(){@Override public void onLocationChanged(Location l){lm.removeUpdates(this);query(l);}};
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,0,0,listener,getMainLooper());
                handler.postDelayed(()->lm.removeUpdates(listener),45000);
            }catch(Exception ignored){}
            return;
        }
        query(latest);
    }
    private void query(Location loc){
        android.content.SharedPreferences p=getSharedPreferences(TrafficMonitorActivity.PREF,0);
        String key=p.getString("api","");
        String lat=p.getString("home_lat","");String lon=p.getString("home_lon","");
        if(key.isEmpty()||lat.isEmpty()||lon.isEmpty())return;
        new Thread(()->{
            HttpURLConnection c=null;
            try{
                JSONObject body=new JSONObject();
                body.put("origin",waypoint(loc.getLatitude(),loc.getLongitude()));
                body.put("destination",waypoint(Double.parseDouble(lat),Double.parseDouble(lon)));
                body.put("travelMode","DRIVE");body.put("routingPreference","TRAFFIC_AWARE");
                URL url=new URL("https://routes.googleapis.com/directions/v2:computeRoutes");
                c=(HttpURLConnection)url.openConnection(); c.setRequestMethod("POST");c.setDoOutput(true);c.setConnectTimeout(10000);c.setReadTimeout(15000);
                c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("X-Goog-Api-Key",key);c.setRequestProperty("X-Goog-FieldMask","routes.duration,routes.staticDuration");
                try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes("UTF-8"));}
                int status=c.getResponseCode(); if(status!=200){postStatus("Traffic API error: HTTP "+status);return;}
                ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] data=new byte[2048];int k;while((k=in.read(data))!=-1)out.write(data,0,k);}
                JSONArray routes=new JSONObject(out.toString("UTF-8")).getJSONArray("routes");if(routes.length()==0){postStatus("No route found");return;}
                JSONObject route=routes.getJSONObject(0);
                double live=seconds(route.getString("duration"));double base=seconds(route.getString("staticDuration"));
                int delay=(int)Math.round(Math.max(0,(live-base)/60));
                postStatus("Route home "+Math.round(live/60)+" min; traffic +"+delay+" min");
                if(delay>=10 && System.currentTimeMillis()-lastAlert>30*60*1000L){lastAlert=System.currentTimeMillis();alert(delay,(int)Math.round(live/60));}
            }catch(Exception e){postStatus("Traffic check failed: "+e.getClass().getSimpleName());}finally{if(c!=null)c.disconnect();}
        }).start();
    }
    private JSONObject waypoint(double lat,double lon)throws JSONException{JSONObject ll=new JSONObject();ll.put("latitude",lat);ll.put("longitude",lon);JSONObject location=new JSONObject();location.put("latLng",ll);JSONObject wrapper=new JSONObject();wrapper.put("location",location);return wrapper;}
    private double seconds(String s){return Double.parseDouble(s.replace("s",""));}
    private void postStatus(String s){((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(7820,n("MKamuy traffic",s));}
    private void alert(int delay,int eta){
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel("mkamuy_congestion","Major congestion alerts",NotificationManager.IMPORTANCE_HIGH));
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"mkamuy_congestion"):new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle("Major congestion towards home").setContentText("+"+delay+" min delay. ETA "+eta+" min.").setAutoCancel(true).setDefaults(Notification.DEFAULT_ALL);
        nm.notify(7821,b.build());
    }
}
