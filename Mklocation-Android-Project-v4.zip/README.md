# MKamuy Location V4 — typed home address

This is a **separate Android app** and does not modify the original S999 launcher.

## Set up on S999
1. Open MKamuy Traffic. The first section is **HOME ADDRESS — TYPE YOUR ADDRESS**.
2. Enter your full address, suburb and postcode. Tap **SAVE TYPED HOME ADDRESS**.
3. Confirm the resolved address in the dialog. You can cancel and edit the text if it is wrong.
4. Add your Google Routes API key (Google Cloud billing and Routes API required).
5. Tap **TEST NOTIFICATION** to check permission and alerts.
6. Allow precise location, then tap **START TRAFFIC MONITOR**.

The geocoder might transmit the entered address to its external lookup provider; the text and resulting coordinates are saved in local app preferences and **not committed to GitHub**. The Routes API sends GPS origin and saved home coordinates to Google during traffic checks. API keys stored in app preferences are not hardware-backed secrets.

Two qualifying GPS speed readings above 40 km/h switch on vehicle mode. Every 15 minutes while in vehicle mode, the app queries Google Routes, and alerts when route duration exceeds static duration by at least 10 minutes (with a 30-minute alert cooldown). After vehicle mode starts, slowing down does not immediately disable it; it expires after 30 minutes without a qualifying >40 km/h reading. This is a heuristic, not definitive vehicle classification. Android background and GPS restrictions may affect reliability.

Build with main.yml uploaded to `.github/workflows/main.yml` and project ZIP in repository root. The workflow creates a debug APK in Actions artifacts. APK not tested on physical S999.
