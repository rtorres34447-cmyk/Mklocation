# MKamuy Location: standalone S999 traffic monitor

This is a **separate Android app**. It does not modify the existing S999 theme or launcher repository.

- GPS origin from S999; save HOME on device while physically at home.
- Google Routes traffic comparison (`duration` vs `staticDuration`), alert at **10+ extra minutes**.
- While foreground monitoring service is active, check about every **15 minutes**; Android may suspend or stop it.
- Saves home coordinates and user-provided Google Routes API key in local app preferences. Never commit your home or API key.
- Target is API 32 to support older watch Android versions. Android 13+ notification permission and recent foreground location requirements vary by device.

## GitHub build

Upload the **separate** `Mklocation-Android-Project.zip` and the `.github/workflows/main.yml` workflow to the root and workflow path respectively of the `Mklocation` GitHub repository. Run **Actions > Build MKamuy Location APK > Run workflow**. Download `Mklocation-debug-APK` from run artifacts. Don't unzip the Android project into the GitHub repository; the workflow unpacks it for the build.

## Device setup

1. Install debug APK and enable Location services and internet on S999.
2. While physically at home, open `MKamuy Traffic`, allow precise location, then tap **SET CURRENT GPS POSITION AS HOME**. Confirm the home-saved message. No address is committed to GitHub.
3. In Google Cloud Console enable Routes API and billing, set strict quota caps/alerts, create a Routes-API-limited key; paste it into app and save. API requests can incur charges. Since the app sends requests directly, a key stored on a device cannot be fully secured; for long-term use a backend proxy is preferable.
4. Tap **START TRAFFIC MONITOR** and allow notifications. A persistent notification shows its status. Disable battery optimization if the S999 firmware terminates the service.
5. **STOP TRAFFIC MONITOR** ends monitoring. Background restarts after device reboot are not implemented.

## Limitations

Prototype is untested on physical S999. Google `staticDuration` is not a prediction of an actual historic route; Google may choose a different route for traffic. 15-minute checks occur while service stays alive and are not a guaranteed precise schedule. Checking begins right away. Foreground service must start while app is visible. To avoid Google Routes costs, stop monitoring when not needed. No API key, home coordinates, or destination address should be committed in GitHub. The repository is not assumed to be private.
